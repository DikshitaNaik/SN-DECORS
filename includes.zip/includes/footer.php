
<footer class="footer ftco-section">
    <div class="container">
        <div class="row mt-5">
            <div class="col-md-12 text-center">
                <p class="copyright">
                    Copyright &copy;<script>document.write(new Date().getFullYear());</script> Online Decoration Management System 
                </p>
            </div>
        </div>
    </div>
</footer>