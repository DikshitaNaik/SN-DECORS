<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Decoration Management System - Services</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/animate.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/magnific-popup.css">
  <link rel="stylesheet" href="css/flaticon.css">
  <link rel="stylesheet" href="css/style.css">
  
  <style>
    .service-box {
      position: relative;
      text-align: center;
      margin-bottom: 50px;
      border: 1px solid #ddd;
      padding: 20px;
      background: #fff;
      transition: transform 0.3s ease;
    }

    .service-box img {
      width: 100%;
      height: 150px;
      object-fit: cover;
      transition: transform 0.3s ease-in-out;
    }

    .service-box:hover img {
      transform: scale(1.3);
    }

    .service-box .details {
      margin-top: 15px;
    }

    .service-box .details h4 {
      margin-bottom: 10px;
      font-size: 18px;
      font-weight: bold;
    }

    .service-box .details p {
      font-size: 14px;
      color: #555;
    }

    .service-box .details .price {
      display: block;
      font-size: 20px;
      margin-bottom: 15px;
      color: #007bff;
    }

    .service-box .details .btn {
      background-color: #800080; /* Purple color */
      color: white;
      text-decoration: none;
      padding: 10px 20px;
      border-radius: 5px;
      transition: background 0.3s ease;
    }

    .service-box .details .btn:hover {
      background-color: #4b0082; /* Darker purple */
    }
  </style>
</head>
<body>
 <?php include('includes/header.php'); ?>
 <!-- END nav -->
 <section class="hero-wrap hero-wrap-2" style="background-image: url('images/img10.jpeg');" data-stellar-background-ratio="0.5">
  <div class="overlay"></div>
  <div class="container">
    <div class="row no-gutters slider-text align-items-end">
      <div class="col-md-9 ftco-animate pb-5">
       <p class="breadcrumbs mb-2"><span class="mr-2"><a href="index.php">Home <i class="fa fa-chevron-right"></i></a></span> <span>Services <i class="fa fa-chevron-right"></i></span></p>
       <h1 class="mb-0 bread">Services</h1>
     </div>
   </div>
 </div>
</section>

<section class="ftco-section bg-light">
  <div class="container">
    <div class="row justify-content-center pb-5 mb-3">
      <div class="col-md-7 heading-section text-center ftco-animate">
        <h2>Choose Your Perfect Service</h2>
      </div>
    </div>
    <div class="row">
      <?php
      $services = [
        ["name" => "Wedding Decoration", "price" => 40000, "description" => "Make your wedding day even more memorable with our stunning decoration services.", "image" => "images/img18.jpeg"],
        ["name" => "Reception Decoration", "price" => 30000, "description" => "Create a beautiful atmosphere for your reception with custom-designed decorations.", "image" => "images/img9.jpeg"],
        ["name" => "Engagement Decoration", "price" => 25000, "description" => "Celebrate your engagement with elegant decorations that reflect your love.", "image" => "images/img20.jpeg"],
        ["name" => "Haldi Decoration", "price" => 10000, "description" => "Traditional halsi decoration that brings a rustic charm to your celebration.", "image" => "images/img10.jpeg"],
        ["name" => "Mehendi Decoration", "price" => 7000, "description" => "Bring color and joy to your mehendi ceremony with vibrant and lively decorations.", "image" => "images/img21.jpeg"],
        ["name" => "Sangeet Decoration", "price" => 11000, "description" => "Set the mood for a lively sangeet ceremony with enchanting decorations.", "image" => "images/img5.jpeg"],
        ["name" => "Baby Shower Decoration", "price" => 9000, "description" => "Welcome your little one with soft, charming decorations for the baby shower.", "image" => "images/img15.jpeg"],
        ["name" => "Naming Ceremony Decoration", "price" => 9500, "description" => "Celebrate your baby's naming ceremony with delightful and meaningful decorations.", "image" => "images/img16.jpeg"]
      ];

      foreach ($services as $service) {  
      ?>
        <div class="col-md-6 col-lg-3 ftco-animate">
          <div class="service-box">
            <img src="<?php echo $service['image']; ?>" alt="<?php echo $service['name']; ?>">
            <div class="details">
              <h4><?php echo htmlentities($service["name"]); ?></h4>
              <span class="price">₹<?php echo htmlentities($service["price"]); ?></span>
              <p><?php echo htmlentities($service["description"]); ?></p>
              <a href="book_services.php?bookid=<?php echo urlencode($service["name"]); ?>" class="btn">Book</a>
            </div>
          </div>
        </div>
      <?php 
      }
      ?>
    </div>
  </div>
</section>

<?php include('includes/footer.php'); ?>

<!-- loader -->
<div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>

<script src="js/jquery.min.js"></script>
<script src="js/jquery-migrate-3.0.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/jquery.animateNumber.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/scrollax.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
<script src="js/google-map.js"></script>
<script src="js/main.js"></script>

</body>
</html>
